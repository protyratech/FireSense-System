#include<dht.h> //To include a library to read data from dht11 sensor
#include <LiquidCrystal.h>
// initialize the library by associating any needed LCD interface pin
// with the arduino pin number it is connected to
const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
#define dht_dpin 8 //DHT data pin is connected to pin 2 on the Arduino Board
dht DHT;
byte degree[8] =
{
0b00011,
0b00011,
0b00000,
0b00000,
0b00000,
0b00000,
0b00000,
0b00000
}; // This line is to create a custom Degree sign in degree celcius.
int buzzer = 7;
int flame_sensor = 9;
int flame_detected;
int i=0, j=0;

void setup() {
  // set up the LCD's number of columns and rows:
  lcd.begin(16, 2);
  lcd.createChar(1, degree); //we assign a number 1 to the degree sign created above
lcd.clear();
lcd.print("Temp & Humidity");
lcd.setCursor(0,1);
lcd.print(" Measurement "); // Print the words Humidity Measurement on LCD screen
delay(2000); // Keep the words on screen for two seconds
lcd.clear(); // clear the screen for writing anything else
lcd.print(" FireSense ");
lcd.setCursor(0,1);
lcd.print(" System ");
delay(2000);
pinMode(buzzer,OUTPUT);
}

void loop() {
  DHT.read11(dht_dpin); // This command will read the incoming data from the DHT11 sensor
lcd.setCursor(0,0); // Setting Curser on First character of first line
lcd.print("Humidity: "); // printing the word Humidity: on the display
lcd.print(DHT.humidity); // printing Humidity value we got from the Sensor on the LCD
lcd.print("%");
lcd.setCursor(0,1); // setting curser on First character on 2nd line
lcd.print("Temp: ");
lcd.print(DHT.temperature); // Printing temperature reading we got from Sensor on the LCD
lcd.write(1); // Write the custom charecter we created (degree sign)
lcd.print("C");
delay(1000); // refresh every half second
flame_detected = digitalRead(flame_sensor);
 lcd.clear( );
  if (flame_detected == 0)
  { 
     digitalWrite(buzzer, HIGH);
      for (j = 15 ; j <= -5 ; j++) {
      lcd.setCursor(j, i);
      lcd.print("Flame detected!");
      lcd.setCursor(j, 0);
       lcd.print("take action immediate.");
      delay(400);
      lcd.clear( );
      }
   }
   else
  {
    digitalWrite(buzzer, LOW);
  } 
}